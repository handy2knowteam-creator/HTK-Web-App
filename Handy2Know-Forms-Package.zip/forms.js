// Replace with your actual SheetMonkey endpoints
const customerURL = "https://api.sheetmonkey.io/form/your-customers-endpoint";
const tradeURL    = "https://api.sheetmonkey.io/form/your-trades-endpoint";

document.addEventListener("DOMContentLoaded", () => {

  // ---------- CUSTOMERS ----------
  const cForm = document.getElementById("customerForm");
  const cStatus = document.getElementById("customerStatus");

  if (cForm) {
    cForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(cForm);
      const payload = {
        "Name": fd.get("name")?.trim(),
        "Email": fd.get("email")?.trim(),
        "Phone": fd.get("phone")?.trim(),
        "Address": fd.get("address")?.trim(),
        "Postcode": fd.get("postcode")?.trim(),
        "Job Description": fd.get("jobDescription")?.trim(),
        "Budget": fd.get("budget")?.trim(),
        "Preferred Date/Time": fd.get("preferredDate") || ""
      };
      cStatus.textContent = "Sending...";
      fetch(customerURL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      .then(r => {
        if (r.ok) { cStatus.textContent = "Thanks — we’ll be in touch!"; cForm.reset(); }
        else { cStatus.textContent = "Error, please try again."; }
      })
      .catch(() => cStatus.textContent = "Network error.");
    });
  }

  // ---------- TRADES ----------
  const tForm = document.getElementById("tradeForm");
  const tStatus = document.getElementById("tradeStatus");

  if (tForm) {
    tForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(tForm);
      const payload = {
        "Name": fd.get("name")?.trim(),
        "Email": fd.get("email")?.trim(),
        "Phone": fd.get("phone")?.trim(),
        "Address": fd.get("address")?.trim(),
        "Trade Type": fd.get("tradeType")?.trim(),
        "Details": fd.get("details")?.trim(),
        "Availability": fd.get("availability") || ""
      };
      tStatus.textContent = "Sending...";
      fetch(tradeURL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      .then(r => {
        if (r.ok) { tStatus.textContent = "Application received!"; tForm.reset(); }
        else { tStatus.textContent = "Error, please try again."; }
      })
      .catch(() => tStatus.textContent = "Network error.");
    });
  }

});
